import "@hotwired/turbo-rails";
import "controllers";
import "dashboard";
import "itineraries";
import "destinations";
import "starting_points";
import "day_schedule";
