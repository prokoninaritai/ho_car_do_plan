console.log("Debug: day_schedule.js is loaded");
document.addEventListener("turbo:load", () => {
  console.log("Day Schedule JS Loaded with Turbo");
});
